# Calculadora de interés compuesto (ARS)

Calculadora interactiva de interés compuesto pensada para ahorristas en Argentina: en pesos, en español y pensada para usar desde el celular.

**Demo:** https://calculadora-interes-ar.vercel.app

## Qué hace

- Controles deslizables (y recuadros para escribir el número) para: ahorro inicial, aporte mensual, años y rendimiento anual.
- Muestra cuánto se tendría al final y separa lo que puso la persona de lo que generaron los intereses.
- Gráfico de aportes e intereses a lo largo del tiempo.
- Indica el año exacto en que los intereses acumulados superan a los aportes.
- Modo "pesos de hoy": descuenta una inflación anual supuesta para mostrar el poder de compra real.
- Comparador: empezar hoy vs. empezar dentro de 5 años, con los mismos aportes y la misma fecha final.

El rendimiento y la inflación son supuestos que elige quien usa la calculadora. No son una garantía.

## Cómo está hecha

Un único archivo `index.html` con HTML, CSS y JavaScript, sin dependencias ni paso de compilación. Para usarla, abrirla en un navegador o publicarla en cualquier hosting estático.

## Cómo calcula

- El rendimiento anual se convierte a su equivalente mensual compuesto.
- Los aportes se suman a fin de cada mes.
- En el modo "pesos de hoy", cada monto se divide por el aumento de precios acumulado hasta ese mes.
- En el comparador, si se empieza más tarde, el ahorro inicial queda guardado sin rendir hasta ese momento.

## Qué quedó afuera

Impuestos, comisiones, aportes que se actualicen con la inflación y rendimientos distintos cada año.

Es una simulación con fines ilustrativos, no asesoramiento financiero.
